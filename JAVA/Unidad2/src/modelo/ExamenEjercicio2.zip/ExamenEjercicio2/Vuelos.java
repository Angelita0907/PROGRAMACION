package modelo.ExamenEjercicio2;

public enum Vuelos {
	LOW_COST, NORMAL, EXPRESS
}
