package modelo.ExamenEjercicio2;

public interface IRuta {
	
	public double getCoste();
	public String getTipoRuta();

}
