package modelo.ExamenEjercicio1;

public enum TipoPremium {
	PREMIUM, PREMIU_VIP
}
