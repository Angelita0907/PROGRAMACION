package modelo.ExamenEjercicio1;

public class GuzmanitosException extends Exception{

	public GuzmanitosException(String mensaje) {
		super(mensaje);
		// TODO Auto-generated constructor stub
	}

}
